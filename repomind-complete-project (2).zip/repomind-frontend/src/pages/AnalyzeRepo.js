import { useState } from "react";
import api from "../api/axios";
import { toast } from "react-toastify";

const PROGRESS_STEPS = [
  "Fetching commits...",
  "Checking code patterns...",
  "Comparing historical bugs...",
  "Running AI analysis...",
  "Generating recommendations...",
];

function parseRepoUrl(url) {
  try {
    const clean = url.trim().replace(/\.git$/, "").replace(/\/$/, "");
    const match = clean.match(/github\.com\/([^/]+)\/([^/]+)/i);
    if (!match) return null;
    return { owner: match[1], repo: match[2] };
  } catch {
    return null;
  }
}

export default function AnalyzeRepo() {
  const [repoUrl, setRepoUrl] = useState("");
  const [loading, setLoading] = useState(false);
  const [stepIndex, setStepIndex] = useState(0);
  const [result, setResult] = useState(null);
  const [error, setError] = useState("");

  const runProgressAnimation = () => {
    let i = 0;
    setStepIndex(0);
    const interval = setInterval(() => {
      i += 1;
      if (i < PROGRESS_STEPS.length) {
        setStepIndex(i);
      } else {
        clearInterval(interval);
      }
    }, 900);
    return interval;
  };

  const handleAnalyze = async (e) => {
    e.preventDefault();
    setError("");
    setResult(null);

    const parsed = parseRepoUrl(repoUrl);
    if (!parsed) {
      setError("Please enter a valid GitHub repository URL, e.g. https://github.com/owner/repo");
      return;
    }

    setLoading(true);
    const progressTimer = runProgressAnimation();

    try {
      const res = await api.get("/fetch-commits", {
        params: { owner: parsed.owner, repo: parsed.repo },
      });
      setResult({ ...res.data, owner: parsed.owner, repo: parsed.repo });
      toast.success(res.data.message || "Analysis complete!");
    } catch (err) {
      const msg =
        err.response?.data?.error ||
        err.response?.data?.message ||
        "Could not analyze this repository. Please check the URL and try again.";
      setError(msg);
      toast.error(msg);
    } finally {
      clearInterval(progressTimer);
      setLoading(false);
    }
  };

  return (
    <div className="analyze-page">
      <h2>Analyze Repository</h2>
      <p className="analyze-subtext">
        Paste a public GitHub repository URL. RepoMind will fetch recent bug-fix commits,
        assign a risk severity, and explain each one in plain language.
      </p>

      <form className="analyze-form" onSubmit={handleAnalyze}>
        <input
          type="text"
          className="analyze-input"
          placeholder="https://github.com/owner/repository"
          value={repoUrl}
          onChange={(e) => setRepoUrl(e.target.value)}
          disabled={loading}
        />
        <button className="btn-primary" type="submit" disabled={loading}>
          {loading ? "Analyzing..." : "Analyze Repository"}
        </button>
      </form>

      {error && !loading && <div className="analyze-error">{error}</div>}

      {loading && (
        <div className="analyze-progress">
          {PROGRESS_STEPS.map((step, idx) => (
            <div
              key={step}
              className={`progress-step ${idx <= stepIndex ? "active" : ""}`}
            >
              <span className="progress-dot" />
              {step}
            </div>
          ))}
        </div>
      )}

      {result && !loading && (
        <div className="analyze-results">
          <div className="repo-meta">
            <span className="repo-name">
              {result.owner}/{result.repo}
            </span>
            <span className="commit-count">{result.commits?.length || 0} bug-fix commits found</span>
          </div>

          {(!result.commits || result.commits.length === 0) ? (
            <p className="empty-state">No risky patterns were detected in this analysis.</p>
          ) : (
            <div className="commit-list">
              {result.commits.map((c) => (
                <div key={c.sha} className={`commit-card severity-${c.severity?.toLowerCase()}`}>
                  <div className="commit-header">
                    <span className="severity-badge">{c.severity}</span>
                    <span className="commit-date">
                      {c.created_at ? new Date(c.created_at).toLocaleDateString() : ""}
                    </span>
                  </div>
                  <p className="commit-message">{c.message}</p>
                  <p className="commit-explanation">{c.explanation}</p>
                </div>
              ))}
            </div>
          )}
        </div>
      )}
    </div>
  );
}
