import { Link } from "react-router-dom";
import { useAuth } from "../context/AuthContext";

export default function Home() {
  const { user } = useAuth();

  return (
    <div className="home">
      <section className="hero">
        <h1>
          🧠 Repo<span className="accent">Mind</span>
        </h1>
        <p className="hero-tagline">Catch risky code before it becomes a bug.</p>
        <p className="hero-subtext">
          RepoMind learns from your repository's past bugs and code history to
          identify risky patterns, explain why they matter, and suggest fixes
          before they cause problems.
        </p>
        <div className="hero-actions">
          <Link to={user ? "/dashboard" : "/login"} className="btn-primary">
            View Dashboard
          </Link>
          {!user && (
            <Link to="/signup" className="btn-secondary">
              Get Started
            </Link>
          )}
        </div>
      </section>

      <section className="features">
        <div className="feature-card">
          <h3>🔍 Risk Detection</h3>
          <p>Automatically flags risky code changes with a clear severity level.</p>
        </div>
        <div className="feature-card">
          <h3>🤖 AI-Powered Explanations</h3>
          <p>Every issue comes with a plain-language explanation and a suggested fix.</p>
        </div>
        <div className="feature-card">
          <h3>📜 Repository History</h3>
          <p>Learns from past bugs in your repo to spot similar patterns early.</p>
        </div>
      </section>

      <footer className="home-footer">
        <p>RepoMind — BCA Minor Project</p>
      </footer>
    </div>
  );
}
