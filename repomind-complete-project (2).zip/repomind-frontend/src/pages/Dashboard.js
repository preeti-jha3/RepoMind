import { useEffect, useState } from "react";
import { useAuth } from "../context/AuthContext";
import api from "../api/axios";
import { toast } from "react-toastify";

export default function Dashboard() {
  const { user } = useAuth();
  const [commits, setCommits] = useState([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState("");
  const [filter, setFilter] = useState("All");

  useEffect(() => {
    const fetchCommits = async () => {
      try {
        const res = await api.get("/api/commits");
        setCommits(res.data);
      } catch (err) {
        toast.error("Commits load nahi ho paaye");
      } finally {
        setLoading(false);
      }
    };
    fetchCommits();
  }, []);

  const filtered = commits.filter((c) => {
    const matchesSearch = c.message?.toLowerCase().includes(search.toLowerCase());
    const matchesFilter = filter === "All" || c.severity === filter;
    return matchesSearch && matchesFilter;
  });

  const counts = {
    High: commits.filter((c) => c.severity === "High").length,
    Medium: commits.filter((c) => c.severity === "Medium").length,
    Low: commits.filter((c) => c.severity === "Low").length,
  };

  return (
    <div className="dashboard">
      <h2>Dashboard</h2>
      <p>Welcome, {user?.name} 👋</p>

      <div className="stats-row">
        <div className="stat-card">
          <span className="stat-number">{commits.length}</span>
          <span className="stat-label">Total</span>
        </div>
        <div className="stat-card severity-high">
          <span className="stat-number">{counts.High}</span>
          <span className="stat-label">High</span>
        </div>
        <div className="stat-card severity-medium">
          <span className="stat-number">{counts.Medium}</span>
          <span className="stat-label">Medium</span>
        </div>
        <div className="stat-card severity-low">
          <span className="stat-number">{counts.Low}</span>
          <span className="stat-label">Low</span>
        </div>
      </div>

      <div className="controls-row">
        <input
          className="search-input"
          placeholder="Search commits..."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
        />
        <select value={filter} onChange={(e) => setFilter(e.target.value)}>
          <option value="All">All Severity</option>
          <option value="High">High</option>
          <option value="Medium">Medium</option>
          <option value="Low">Low</option>
        </select>
      </div>

      {loading ? (
        <div className="loader">Loading commits...</div>
      ) : filtered.length === 0 ? (
        <p>Koi matching commit nahi mila</p>
      ) : (
        <div className="commit-list">
          {filtered.map((c) => (
            <div key={c.id} className={`commit-card severity-${c.severity?.toLowerCase()}`}>
              <div className="commit-header">
                <span className="severity-badge">{c.severity}</span>
                <span className="commit-date">{new Date(c.created_at).toLocaleDateString()}</span>
              </div>
              <p className="commit-message">{c.message}</p>
              <p className="commit-explanation">{c.explanation}</p>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}