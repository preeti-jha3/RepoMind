const express = require('express');
const { Pool } = require('pg');
const axios = require('axios');
const { GoogleGenerativeAI } = require('@google/generative-ai');
require('dotenv').config();
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const cors = require('cors');

const app = express();
const PORT = process.env.PORT || 5000;

const allowedOrigins = [
  'http://localhost:3000',
  process.env.FRONTEND_URL, // e.g. https://repomind-frontend.vercel.app
];
app.use(cors({
  origin: function (origin, callback) {
    if (!origin || allowedOrigins.includes(origin)) {
      callback(null, true);
    } else {
      callback(new Error('Not allowed by CORS'));
    }
  }
}));
app.use(express.json());

const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  ssl: { rejectUnauthorized: false }
});

pool.connect()
  .then(() => {
    console.log('Supabase database is connected!');
  })
  .catch((err) => {
    console.log('Error in Database connection:', err.message);
  });

const genAI = new GoogleGenerativeAI(process.env.GEMINI_API_KEY);

// ---- AUTH MIDDLEWARE ----
function verifyToken(req, res, next) {
  const authHeader = req.headers.authorization;
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    return res.status(401).json({ message: 'No token provided' });
  }
  const token = authHeader.split(' ')[1];
  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    req.userId = decoded.id;
    next();
  } catch (err) {
    return res.status(401).json({ message: 'Invalid or expired token' });
  }
}

app.get('/', (req, res) => {
  res.send('RepoMind Backend is running!');
});

app.get('/api/health', (req, res) => {
  res.json({ status: 'ok', db: pool ? 'connected' : 'unknown' });
});

app.get('/api/analyze', (req, res) => {
  res.json({
    status: 'Success',
    summary: {
      risk: 'High',
      file: 'auth.js - Line 42',
      issue: 'This code has caused bugs before',
      fix: 'Add a NULL check'
    }
  });
});

function getSeverity(message) {
  const lowerMessage = message.toLowerCase();
  const highKeywords = ['security', 'critical', 'crash', 'payment', 'data loss', 'vulnerability'];
  const mediumKeywords = ['error', 'exception', 'fail', 'break'];

  if (highKeywords.some((keyword) => lowerMessage.includes(keyword))) {
    return 'High';
  } else if (mediumKeywords.some((keyword) => lowerMessage.includes(keyword))) {
    return 'Medium';
  } else {
    return 'Low';
  }
}

async function getExplanation(message) {
  try {
    const model = genAI.getGenerativeModel({ model: 'gemini-3.6-flash' });
    const prompt = `Explain in 2 simple lines what bug this commit message is fixing: "${message}"`;

    const result = await model.generateContent(prompt);
    return result.response.text();
  } catch (error) {
    console.log('GEMINI ERROR:', error.message);
    return 'Explanation could not be generated.';
  }
}

// ---- FETCH + ANALYZE COMMITS FROM ANY GITHUB REPO ----
// Usage: GET /fetch-commits?owner=facebook&repo=react
app.get('/fetch-commits', verifyToken, async (req, res) => {
  try {
    const owner = req.query.owner || 'facebook';
    const repo = req.query.repo || 'react';

    const response = await axios.get(
      `https://api.github.com/repos/${owner}/${repo}/commits`,
      {
        headers: {
          Authorization: `token ${process.env.GITHUB_TOKEN}`
        }
      }
    );

    const cleanedCommits = response.data.map((commit) => ({
      sha: commit.sha,
      message: commit.commit.message,
      author: commit.commit.author.name,
      date: commit.commit.author.date
    }));

    const bugKeywords = ['fix', 'bug', 'error', 'issue', 'resolve'];
    const bugCommits = cleanedCommits.filter((commit) => {
      const firstPart = commit.message.toLowerCase().substring(0, 30);
      return bugKeywords.some((keyword) => firstPart.includes(keyword));
    });

    const savedCommits = [];

    for (const commit of bugCommits) {
      const severity = getSeverity(commit.message);
      const explanation = await getExplanation(commit.message);

      const result = await pool.query(
        `INSERT INTO commits (sha, message, author, created_at, severity, explanation)
         VALUES ($1, $2, $3, $4, $5, $6)
         ON CONFLICT (sha) DO UPDATE
           SET severity = EXCLUDED.severity,
               explanation = EXCLUDED.explanation
         RETURNING *`,
        [commit.sha, commit.message, commit.author, commit.date, severity, explanation]
      );

      savedCommits.push(result.rows[0]);
    }

    res.json({
      message: `${savedCommits.length} bug-fix commits saved to database!`,
      commits: savedCommits
    });
  } catch (error) {
    console.log('FETCH-COMMITS ERROR:', error.message);
    if (error.response?.status === 404) {
      return res.status(404).json({ error: 'Repository not found' });
    }
    if (error.response?.status === 403) {
      return res.status(403).json({ error: 'GitHub API rate limit exceeded or invalid token' });
    }
    res.status(500).json({ error: error.message });
  }
});

// ---- AUTH ROUTES ----
app.post('/api/auth/signup', async (req, res) => {
  try {
    const { name, email, password } = req.body;
    if (!name || !email || !password) {
      return res.status(400).json({ message: 'All fields are required' });
    }

    const existing = await pool.query('SELECT * FROM users WHERE email = $1', [email]);
    if (existing.rows.length > 0) {
      return res.status(400).json({ message: 'Email already registered' });
    }

    const hashedPassword = await bcrypt.hash(password, 10);
    const result = await pool.query(
      'INSERT INTO users (name, email, password) VALUES ($1, $2, $3) RETURNING id, name, email',
      [name, email, hashedPassword]
    );

    res.status(201).json({ message: 'Signup successful', user: result.rows[0] });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

app.post('/api/auth/login', async (req, res) => {
  try {
    const { email, password } = req.body;
    const result = await pool.query('SELECT * FROM users WHERE email = $1', [email]);
    const user = result.rows[0];

    if (!user) {
      return res.status(400).json({ message: 'Invalid email or password' });
    }

    const isMatch = await bcrypt.compare(password, user.password);
    if (!isMatch) {
      return res.status(400).json({ message: 'Invalid email or password' });
    }

    const token = jwt.sign({ id: user.id }, process.env.JWT_SECRET, { expiresIn: '7d' });

    res.json({
      token,
      user: { id: user.id, name: user.name, email: user.email }
    });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// ---- GET ALL SAVED COMMITS (for dashboard) ----
app.get('/api/commits', verifyToken, async (req, res) => {
  try {
    const result = await pool.query('SELECT * FROM commits ORDER BY created_at DESC');
    res.json(result.rows);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});
